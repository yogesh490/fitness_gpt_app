import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(SaitamaFitnessApp(prefs: prefs));
}

class SaitamaFitnessApp extends StatelessWidget {
  final SharedPreferences prefs;
  SaitamaFitnessApp({required this.prefs});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Saitama Fitness',
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: Colors.deepPurpleAccent,
        scaffoldBackgroundColor: Colors.black,
        textTheme: TextTheme(
          bodyMedium: TextStyle(color: Colors.white70),
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.deepPurple,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.deepPurpleAccent,
            foregroundColor: Colors.white,
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
          ),
        ),
      ),
      home: DashboardPage(prefs: prefs),
    );
  }
}

class DashboardPage extends StatefulWidget {
  final SharedPreferences prefs;
  DashboardPage({required this.prefs});

  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final List<String> todayWorkout = [
    '100 Push-ups',
    '100 Sit-ups',
    '100 Squats',
    '10KM Run'
  ];

  int xp = 0;
  int level = 1;
  final FlutterLocalNotificationsPlugin notificationsPlugin = FlutterLocalNotificationsPlugin();

  @override
  void initState() {
    super.initState();
    _loadProgress();
    _setupNotifications();
  }

  void _loadProgress() {
    setState(() {
      xp = widget.prefs.getInt('xp') ?? 0;
      level = widget.prefs.getInt('level') ?? 1;
    });
  }

  void _increaseXP() {
    setState(() {
      xp += 10;
      if (xp >= level * 100) {
        xp = 0;
        level++;
      }
      widget.prefs.setInt('xp', xp);
      widget.prefs.setInt('level', level);
    });
  }

  void _setupNotifications() async {
    const AndroidInitializationSettings initializationSettingsAndroid = AndroidInitializationSettings('@mipmap/ic_launcher');
    final InitializationSettings initializationSettings = InitializationSettings(android: initializationSettingsAndroid);
    await notificationsPlugin.initialize(initializationSettings);

    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'daily_reminder',
      'Daily Reminder',
      channelDescription: 'Daily workout reminder',
      importance: Importance.max,
      priority: Priority.high,
    );
    const NotificationDetails platformDetails = NotificationDetails(android: androidDetails);
    await notificationsPlugin.periodicallyShow(
      0,
      'Workout Time!',
      'Complete your Saitama routine today!',
      RepeatInterval.daily,
      platformDetails,
      androidAllowWhileIdle: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Saitama Training Dashboard')),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Level: $level', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.amber)),
                SizedBox(height: 4),
                LinearProgressIndicator(
                  value: xp / (level * 100),
                  backgroundColor: Colors.white24,
                  color: Colors.deepPurpleAccent,
                ),
                SizedBox(height: 16),
                Text('Today's Workout', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white)),
              ],
            ),
          ),
          ...todayWorkout.map((exercise) => ListTile(
            leading: Icon(Icons.fitness_center, color: Colors.deepPurpleAccent),
            title: Text(
              exercise,
              style: TextStyle(color: Colors.white),
            ),
            trailing: Checkbox(value: false, onChanged: (val) => _increaseXP()),
          )),
          Spacer(),
          Padding(
            padding: EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AssistantPage()),
                );
              },
              child: Text('Ask GPT Assistant'),
            ),
          )
        ],
      ),
    );
  }
}

class AssistantPage extends StatefulWidget {
  @override
  State<AssistantPage> createState() => _AssistantPageState();
}

class _AssistantPageState extends State<AssistantPage> {
  final TextEditingController _controller = TextEditingController();
  String _response = '';

  Future<void> _askGPT(String question) async {
    const apiKey = 'YOUR_OPENAI_API_KEY';
    final url = Uri.parse('https://api.openai.com/v1/chat/completions');

    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({
        "model": "gpt-3.5-turbo",
        "messages": [
          {"role": "system", "content": "You are a helpful fitness assistant."},
          {"role": "user", "content": question}
        ]
      }),
    );
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      setState(() {
        _response = data['choices'][0]['message']['content'];
      });
    } else {
      setState(() {
        _response = 'Error: ${response.statusCode}';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('GPT Assistant')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Ask me anything...',
                labelStyle: TextStyle(color: Colors.white54),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.deepPurpleAccent),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.deepPurpleAccent),
                ),
              ),
              style: TextStyle(color: Colors.white),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () => _askGPT(_controller.text),
              child: Text('Submit'),
            ),
            SizedBox(height: 20),
            Text(_response, style: TextStyle(color: Colors.white)),
          ],
        ),
      ),
    );
  }
}
